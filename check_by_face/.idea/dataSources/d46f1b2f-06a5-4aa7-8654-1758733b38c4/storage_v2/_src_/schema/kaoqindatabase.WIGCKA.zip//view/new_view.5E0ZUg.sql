create definer = root@`%` view new_view as
select `kaoqindatabase`.`classinfo`.`class_id`  AS `class_id`,
       `kaoqindatabase`.`classinfo`.`course_id` AS `course_id`,
       `kaoqindatabase`.`classinfo`.`className` AS `className`
from `kaoqindatabase`.`classinfo`;

